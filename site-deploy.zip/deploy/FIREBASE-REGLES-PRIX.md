# 🔧 RÈGLES FIRESTORE À METTRE À JOUR

Tu viens d'ajouter la **synchronisation automatique des prix en ligne**. Pour que ça marche, il faut ajouter une règle pour la nouvelle collection `reglages`.

---

## Règles Firestore COMPLÈTES (copie tout)

1. Console Firebase → **Firestore Database** → onglet **"Règles"**
2. **Efface tout** et colle ceci :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /contrats/{contratId} {
      allow read, write: if true;
    }
    match /factures/{factureId} {
      allow read, write: if true;
    }
    match /reglages/{reglageId} {
      allow read, write: if true;
    }
  }
}
```

3. Clique **"Publier"**

---

## Ce qui a changé

J'ai ajouté cette section (la collection `reglages` stocke tes prix) :

```
    match /reglages/{reglageId} {
      allow read, write: if true;
    }
```

C'est tout ! Les règles Storage ne changent pas.

---

## Vérification

Après avoir publié et redéployé le site :

1. Ouvre ton site, connecte-toi en admin
2. Va dans **Exploitation → Tarifs**
3. Modifie un prix de véhicule → clique **Enregistrer les prix véhicules**
4. Tu dois voir en bas à droite le badge vert **☁️ Enregistré en ligne**
5. Ouvre ton site sur un **autre appareil** (ou autre navigateur) → les prix modifiés apparaissent !

Dans la console navigateur (F12), tu verras :
```
[Firebase] ☁ Réglage "adm_vehicles" synchronisé en ligne
```

---

## Ce qui est synchronisé automatiquement en ligne

Désormais, dès que tu modifies l'un de ces éléments, c'est **enregistré en ligne automatiquement** :

- 🚗 **Prix des véhicules** (Exploitation → Tarifs)
- 📍 **Tarifs de livraison** (gares, aéroports, domicile)
- 📅 **Prix journaliers spéciaux** (clic sur une date dans le planning)
- 🎄 **Taux de majoration vacances** (normal, été, Noël)
- 📆 **Périodes de vacances scolaires**

Tout est récupéré automatiquement au chargement du site sur n'importe quel appareil.
