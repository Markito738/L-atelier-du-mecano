# 🔴 CORRECTION ERREUR "line 2 parse error"

## Pourquoi cette erreur ?

Tu as cliqué sur **Realtime Database** — mais notre site utilise **Firestore Database** (produit différent !).

Les règles que je t'ai données sont au format **Firestore**, elles ne marchent PAS dans **Realtime Database** → d'où "parse error".

---

## ✅ LA SOLUTION : utiliser Firestore, PAS Realtime Database

### Étape 1 : Vérifier que tu es au bon endroit

Dans le menu de gauche de la console Firebase, tu dois voir sous **"Build"** :
- ❌ **Realtime Database** ← PAS celui-là
- ✅ **Firestore Database** ← CELUI-CI

**Clique bien sur "Firestore Database"** (celui avec l'icône qui ressemble à des documents empilés).

---

### Étape 2 : Si tu as créé une Realtime Database par erreur

Pas grave, laisse-la vide, elle ne gêne pas. Il faut juste créer **Firestore** à côté :

1. Menu gauche → **Build** → **Firestore Database**
2. Bouton **"Créer une base de données"**
3. **Mode** : coche **"Démarrer en mode test"**
4. **Emplacement** : `eur3 (europe-west)` ou `europe-west1`
5. Clique **"Activer"** → attends 1 minute

---

### Étape 3 : Régler les règles Firestore (LE BON FORMAT)

1. Une fois dans **Firestore Database**, clique sur l'onglet **"Règles"** (en haut, à côté de "Données")
2. Tu verras quelque chose comme ça par défaut :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

3. **Efface TOUT** et colle EXACTEMENT ceci (format Firestore) :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /contrats/{contratId} {
      allow read, write: if true;
    }
    match /factures/{factureId} {
      allow read, write: if true;
    }
  }
}
```

4. Clique **"Publier"**

⚠️ **IMPORTANT** : la première ligne doit être `service cloud.firestore` (Firestore) et NON `service firebase.database` (Realtime). Si tu vois `firebase.database`, c'est que tu es encore dans Realtime Database.

---

### Comment reconnaître les deux formats (pour ne plus te tromper)

| | Realtime Database | Firestore Database |
|---|---|---|
| **Icône** | Ressemble à un arbre/branches | Ressemble à des documents |
| **Format des règles** | JSON avec `{ "rules": {...} }` | Texte avec `service cloud.firestore` |
| **Ce qu'on utilise** | ❌ NON | ✅ OUI |

**Règle Realtime (celle qui causait ton erreur, à NE PAS utiliser)** :
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

**Règle Firestore (la bonne)** :
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /contrats/{contratId} {
      allow read, write: if true;
    }
    match /factures/{factureId} {
      allow read, write: if true;
    }
  }
}
```

---

### Étape 4 : Règles Storage (pour les fichiers)

1. Menu gauche → **Build** → **Storage**
2. Si pas encore créé : **"Commencer"** → mode test → même emplacement → **"Terminé"**
3. Onglet **"Règles"**
4. **Efface tout** et colle :

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}
```

5. Clique **"Publier"**

Ici c'est bien `service firebase.storage` (normal, c'est le produit Storage).

---

## 🎯 Résumé : les 3 produits Firebase

Pour que le site fonctionne, tu dois avoir activé :

1. ✅ **Firestore Database** (données des contrats/factures) — règles `service cloud.firestore`
2. ✅ **Storage** (fichiers PDF et scans) — règles `service firebase.storage`
3. ❌ **Realtime Database** — PAS besoin, ignore-le complètement

Si tu as activé Realtime Database par erreur, ce n'est pas grave, laisse-le vide.
