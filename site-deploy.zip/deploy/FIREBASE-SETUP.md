# 🔥 Configuration Firebase — Guide pas à pas

**Temps requis : 10 minutes**
**Coût : gratuit (5 Go de stockage, 20 000 opérations/jour)**

---

## 📋 ÉTAPE 1 : Créer le projet Firebase

1. Va sur **https://console.firebase.google.com/**
2. Connecte-toi avec ton compte Google (ou crée-en un si besoin)
3. Clique sur **"Ajouter un projet"** (bouton bleu)
4. **Nom du projet** : `atelier-du-mecano` (ou ce que tu veux)
5. **Google Analytics** : tu peux **désactiver** (case décochée) — c'est plus simple
6. Clique **"Créer le projet"** → attends 30 secondes → **"Continuer"**

Tu arrives sur le tableau de bord de ton projet.

---

## 📋 ÉTAPE 2 : Activer Firestore Database (stockage des données)

1. Dans le menu de gauche, clique **"Build"** → **"Firestore Database"**
2. Clique **"Créer une base de données"** (bouton bleu)
3. **Mode de démarrage** : choisis **"Démarrer en mode test"** (règles ouvertes pendant 30 jours)
4. **Emplacement** : choisis **`europe-west1 (Belgique)`** ou **`eur3 (Europe)`** (proche de la France)
5. Clique **"Activer"** → attends 1 minute

✅ Firestore est actif !

---

## 📋 ÉTAPE 3 : Activer Storage (stockage des fichiers)

1. Dans le menu de gauche, clique **"Build"** → **"Storage"**
2. Clique **"Commencer"** (bouton bleu)
3. **Mode** : choisis **"Démarrer en mode test"**
4. **Emplacement** : même que Firestore (`europe-west1` ou `eur3`)
5. Clique **"Terminé"** → attends 30 secondes

✅ Storage est actif !

---

## 📋 ÉTAPE 4 : Configurer les règles de sécurité

### 4.1 — Règles Firestore

1. Va dans **Firestore Database** → onglet **"Règles"** (en haut)
2. **Efface tout le contenu** et colle exactement ceci :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Contrats : création + lecture publique, pas de suppression
    match /contrats/{contratId} {
      allow create, read, update: if true;
      allow delete: if false;
    }
    // Factures : idem
    match /factures/{factureId} {
      allow create, read, update: if true;
      allow delete: if false;
    }
  }
}
```

3. Clique **"Publier"** (bouton bleu)

### 4.2 — Règles Storage

1. Va dans **Storage** → onglet **"Règles"** (en haut)
2. **Efface tout le contenu** et colle exactement ceci :

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /documents/{contratId}/{allPaths=**} {
      allow read, write: if true;
    }
    match /pdfs/{contratId}/{allPaths=**} {
      allow read, write: if true;
    }
  }
}
```

3. Clique **"Publier"** (bouton bleu)

⚠️ **Note sécurité** : ces règles autorisent la lecture publique. C'est acceptable car les URLs contiennent le numéro de contrat (`LOC-YYYYMMDD-HHMM`) qui est difficile à deviner + le token. Pour un vrai niveau bancaire, il faudrait Firebase Authentication (setup avancé).

---

## 📋 ÉTAPE 5 : Autoriser ton domaine Netlify

1. Va dans **Storage** → onglet **"Règles"**
2. Onglet **"Fichiers"** → clique sur ⚙️ engrenage en haut à droite → **"Configuration"**
3. Onglet **"CORS"** — il faut autoriser ton domaine

**En fait plus simple** : Firebase autorise par défaut tous les domaines pour Storage. Passe à l'étape 6.

---

## 📋 ÉTAPE 6 : Récupérer la configuration

1. En haut à gauche, clique sur ⚙️ engrenage → **"Paramètres du projet"**
2. Descends jusqu'à la section **"Vos applications"**
3. Clique sur l'icône **`</>`** (Web)
4. **Pseudo de l'application** : `atelier-mecano-web`
5. **NE PAS cocher** "Configurer également l'hébergement Firebase"
6. Clique **"Enregistrer l'application"**
7. Tu verras un bloc de code avec un objet `firebaseConfig` — **copie-le entièrement**

Le code ressemble à ça :

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyAAAA_exemple_1234567890",
  authDomain: "atelier-du-mecano.firebaseapp.com",
  projectId: "atelier-du-mecano",
  storageBucket: "atelier-du-mecano.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};
```

---

## 📋 ÉTAPE 7 : Coller la configuration dans le site

1. Ouvre **`index.html`** avec un éditeur de texte (Notepad, VS Code, etc.)
2. **Rechercher** (Ctrl+F) : `REMPLACE_MOI_apiKey`
3. Tu trouves ce bloc :

```javascript
const FIREBASE_CONFIG = {
  apiKey: "REMPLACE_MOI_apiKey",
  authDomain: "REMPLACE_MOI.firebaseapp.com",
  projectId: "REMPLACE_MOI_projectId",
  storageBucket: "REMPLACE_MOI.appspot.com",
  messagingSenderId: "REMPLACE_MOI",
  appId: "REMPLACE_MOI_appId"
};
```

4. **Remplace** avec tes vraies valeurs de l'étape 6 (attention à conserver les guillemets `"`).
5. **Sauvegarde** le fichier
6. **Déploie** sur Netlify (glisse le dossier `deploy/` sur ton dashboard Netlify)

---

## ✅ ÉTAPE 8 : Vérifier que ça marche

1. Ouvre ton site : `https://latelierdumecano.netlify.app/`
2. En bas à gauche, tu dois voir apparaître pendant 3 secondes le badge vert **☁️ Cloud actif**
3. Fais un test de réservation complet
4. Va dans **Admin** → **📁 Dossier** d'une réservation
5. Tu dois voir :
   - Badge vert **☁ Cloud synchronisé** en haut
   - Un bloc vert **"☁ PDFs STOCKÉS DANS LE CLOUD"** avec 4 liens
   - Chaque document client affiche un badge vert **☁ CLOUD**

Si tu vois du **💾 LOCAL** partout, c'est que la config Firebase n'est pas bien collée.

---

## 🔍 Comment vérifier tes documents sur Firebase Console

- **Firestore** : Console Firebase → Firestore Database → tu verras une collection `contrats` et une collection `factures` avec chaque réservation
- **Storage** : Console Firebase → Storage → tu verras un dossier `documents/` et un dossier `pdfs/` avec un sous-dossier par contrat

Tu peux **télécharger n'importe quel fichier** directement depuis la console Firebase.

---

## 🆘 En cas de problème

**Le badge ☁️ Cloud actif n'apparaît pas** :
- Ouvre la console du navigateur (F12 → onglet Console)
- Tu verras un message `[Firebase] Non configuré` ou une erreur avec la raison

**Erreur "Missing or insufficient permissions"** :
- Vérifie les règles Firestore (étape 4.1) et Storage (étape 4.2)
- Clique bien sur **"Publier"** après avoir collé les règles

**Erreur "Firebase App named '[DEFAULT]' already exists"** :
- Recharge la page (Ctrl+Shift+R)

---

## 💰 Est-ce que ça coûte quelque chose ?

**Non, gratuit pour ton usage.**

Le plan gratuit "Spark" de Firebase inclut :
- **1 Go de stockage Firestore** (~50 000 contrats)
- **5 Go de stockage fichiers** (~1000 dossiers complets avec PDFs et scans)
- **20 000 lectures/jour** et **20 000 écritures/jour**

Pour dépasser ce plan, il faudrait avoir plus de **1000 réservations/mois**. Le jour où ça arrive, Firebase te préviendra et le plan payant "Blaze" coûte quelques centimes par mois pour ton volume.
