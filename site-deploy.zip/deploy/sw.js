// Service worker DÉSACTIVÉ
// À la demande de l'utilisateur, la fonctionnalité PWA a été retirée.
// Ce SW ne fait plus que se désinstaller lui-même et vider les caches
// pour éviter que d'anciennes versions installées chez les utilisateurs
// continuent à afficher des propositions d'installation.

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', async (event) => {
  event.waitUntil((async () => {
    // Vider tous les caches
    const keys = await caches.keys();
    await Promise.all(keys.map(k => caches.delete(k)));
    // Se désinscrire
    const clients = await self.clients.matchAll();
    await self.registration.unregister();
    // Recharger les onglets ouverts pour qu'ils prennent la version sans SW
    clients.forEach(c => c.navigate(c.url));
  })());
});
