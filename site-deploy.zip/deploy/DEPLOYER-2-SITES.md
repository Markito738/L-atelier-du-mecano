# 🔄 Mettre à jour LES DEUX sites (Netlify + GitHub)

## Bonne nouvelle : les données sont déjà partagées !

Comme **les deux sites utilisent la même base Firebase**, tous tes réglages (prix, contrats, factures, malus, planning...) sont **automatiquement synchronisés** entre :
- `latelierdumecano.netlify.app`
- `markito738.github.io/L-atelier-du-mecano`

Quand tu modifies un prix sur l'un, il apparaît sur l'autre. **Tu n'as rien à faire de spécial pour ça.**

La seule chose à faire : mettre le **même fichier `index.html`** sur les deux hébergeurs quand le code change.

---

## 📤 Déployer sur Netlify

1. Va sur ton dashboard Netlify
2. Glisse-dépose le **contenu** du dossier `deploy/` (pas le dossier lui-même)
3. C'est en ligne en 30 secondes

---

## 📤 Déployer sur GitHub Pages

### Méthode simple (interface web GitHub)

1. Va sur ton dépôt : `https://github.com/markito738/L-atelier-du-mecano`
2. Clique sur le fichier **`index.html`**
3. Clique sur l'icône ✏️ (crayon) en haut à droite pour l'éditer
4. **Supprime tout le contenu** (Ctrl+A puis Suppr)
5. Ouvre le nouveau `index.html` que je t'ai fourni, copie tout (Ctrl+A, Ctrl+C)
6. Colle dans l'éditeur GitHub (Ctrl+V)
7. En bas, clique **"Commit changes"**
8. GitHub Pages met à jour le site en 1-2 minutes

### Méthode avec fichiers (si tu as GitHub Desktop)

1. Remplace `index.html` + les fichiers du dossier `deploy/` dans ton dépôt local
2. Commit + Push

---

## ⚠️ Important : garder les deux identiques

À chaque fois que je te donne un nouveau `index.html`, mets-le sur **les deux** :
- ✅ Netlify (glisser-déposer)
- ✅ GitHub (éditer + commit)

Sinon un site aura les nouvelles fonctions et l'autre les anciennes (mais les **données** resteront synchronisées via Firebase dans tous les cas).

---

## 🎯 Ce qui est partagé automatiquement (via Firebase)

Peu importe le site utilisé, ces éléments sont toujours à jour partout :

- 🚗 Prix et flotte de véhicules
- 📍 Tarifs de livraison
- 📅 Planning et réservations
- 🎄 Périodes de vacances
- 💰 Prix journaliers spéciaux
- 🏷️ Réductions
- 📝 Contrats et factures
- ⚠️ Malus clients
- 🔧 Entretien véhicules
- 👥 Livreurs et utilisateurs
- 🖼️ Photos galerie et services
- 🚘 Véhicules à vendre
- 🎁 Parrainages
- 💬 Avis clients

**En résumé** : les données suivent automatiquement, seul le code (design, fonctions) doit être copié manuellement sur les deux hébergeurs.
